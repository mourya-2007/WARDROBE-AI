import React, { useEffect, useMemo, useRef, useState } from "react";

type ArcCarouselProps = {
  labels: string[];
  images: string[];
  selected: string;
  onSelect: (label: string) => void;
};

type CardPhysics = { angle: number; velocity: number };

export default function ArcCarousel({ labels, images, selected, onSelect }: ArcCarouselProps) {
  const selectedIndex = Math.max(0, labels.indexOf(selected));
  const cards = useRef<(HTMLButtonElement | null)[]>([]);
  const physics = useRef<CardPhysics[]>(labels.map((_, i) => ({ angle: (i - selectedIndex) * 13, velocity: 0 })));
  const target = useRef(selectedIndex);
  const raf = useRef<number | null>(null);
  const [focused, setFocused] = useState(selectedIndex);
  const [hovering, setHovering] = useState(false);
  const reduced = useMemo(() => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches, []);

  useEffect(() => {
    target.current = selectedIndex;
    if (reduced) {
      physics.current.forEach((card, i) => { card.angle = (i - selectedIndex) * 13; card.velocity = 0; });
    }
  }, [selectedIndex, reduced]);

  useEffect(() => {
    let running = true;
    const tick = () => {
      if (!running) return;
      const p = physics.current;
      const lead = p.length - 1;
      const leadTarget = (lead - target.current) * 13;
      p[lead].velocity = (p[lead].velocity + (leadTarget - p[lead].angle) * .13) * .72;
      p[lead].angle += p[lead].velocity;
      for (let i = lead - 1; i >= 0; i--) {
        const next = p[i + 1];
        p[i].velocity = (p[i].velocity + (next.angle - 13 - p[i].angle) * .13) * .72;
        p[i].angle += p[i].velocity;
      }
      let closest = 0;
      let min = Infinity;
      p.forEach((card, i) => {
        const el = cards.current[i];
        if (el) el.style.transform = `translate(-50%, 0) rotate(${card.angle.toFixed(2)}deg)`;
        if (Math.abs(card.angle) < min) { min = Math.abs(card.angle); closest = i; }
      });
      setFocused(old => old === closest ? old : closest);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => { running = false; if (raf.current !== null) cancelAnimationFrame(raf.current); };
  }, []);

  const move = (direction: number) => {
    const next = Math.max(0, Math.min(labels.length - 1, target.current + direction));
    target.current = next;
    onSelect(labels[next]);
  };

  return (
    <section className="occasion-arc" aria-label="Choose an occasion carousel"
      onMouseEnter={() => setHovering(true)} onMouseLeave={() => setHovering(false)}
      onWheel={(event) => {
        if (Math.abs(event.deltaY) > 12 || Math.abs(event.deltaX) > 12) {
          event.preventDefault();
          move((event.deltaY + event.deltaX) > 0 ? 1 : -1);
        }
      }}
      onKeyDown={(event) => {
        if (event.key === "ArrowRight" || event.key === "ArrowDown") { event.preventDefault(); move(1); }
        if (event.key === "ArrowLeft" || event.key === "ArrowUp") { event.preventDefault(); move(-1); }
      }}
      tabIndex={0}>
      <div className="arc-topline"><span>SELECT YOUR MOMENT</span><span>{String(selectedIndex + 1).padStart(2,"0")} <i>/</i> {String(labels.length).padStart(2,"0")}</span></div>
      <div className="arc-stage">
        <div className="arc-halo" />
        <div className="arc-pivot">
          {images.slice(0, labels.length).map((image, index) => (
            <button key={labels[index]} ref={el => { cards.current[index] = el; }}
              className={`arc-card ${selectedIndex === index ? "is-selected" : ""}`}
              style={{ zIndex: labels.length - Math.abs(index - selectedIndex) }}
              onClick={() => { target.current = index; onSelect(labels[index]); }}
              aria-label={`Choose ${labels[index]}`} aria-pressed={selectedIndex === index}>
              <img src={image} alt="" draggable={false} />
              <span className="arc-card-shade" />
              <span className="arc-card-label">{labels[index]}</span>
            </button>
          ))}
        </div>
        <div className="arc-current"><span className="arc-current-number">{String(focused + 1).padStart(2,"0")}</span><span>{labels[focused]}</span></div>
      </div>
      <div className="arc-footer">
        <span>{hovering ? "Scroll or use ← → to explore" : "Explore occasions"} </span>
        <div className="arc-controls">
          <button type="button" onClick={() => move(-1)} disabled={selectedIndex === 0} aria-label="Previous occasion">←</button>
          <button type="button" onClick={() => move(1)} disabled={selectedIndex === labels.length - 1} aria-label="Next occasion">→</button>
        </div>
      </div>
    </section>
  );
}
