# Wardrobe AI — Refined Workspace

A standalone React + Vite wardrobe assistant prototype. The original landing page is retained; the workspace after **Get Started** has been simplified and polished.

## What's included
- Occasion selection via a responsive chained-spring arc carousel.
- Ten occasion choices: College, Work, Casual, Dinner, Date night, Weekend, Travel, Streetwear, Formal and Rainy day.
- Click, scroll-wheel, keyboard-arrow and previous/next controls for the occasion carousel.
- Reduced-motion support and responsive styling.
- Interactive garment rail in My Wardrobe.
- Refined borders, focus states, card treatments, hover/press feedback and responsive layouts throughout the workspace.
- Local browser storage for wardrobe items and saved looks.

## Run locally
Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Production build
```bash
npm run build
npm run preview
```

## Notes
This is a front-end prototype. Outfit recommendations currently use sample data; connect an AI service to enable real personalised generation. Images are loaded from remote image hosts and require an internet connection.

The original `GOOGLE-AI` GitHub repository is not modified by this standalone project.

## Visual refresh notes
- The post-Get Started workspace now shares the landing page's monochrome, Apple-inspired visual language and DM Sans typography.
- Workspace sections reveal softly as they enter the viewport.
- Image frames use consistent cover framing to avoid stretched images.
- The Get Started transition uses a white-and-black Wardrobe AI loading screen with a short progress animation.
